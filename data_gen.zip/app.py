# app.py
import streamlit as st
import pandas as pd
import plotly.express as px

# ---------- Load & prepare data ----------
df = pd.read_csv("ba_orders_2024.csv")
df["net_price"] = df["unit_price"] * (1 - df["discount_pct"])
df["profit"] = df["revenue"] - df["cost"]

summary = df.groupby(["channel", "region"], as_index=False).agg(
    orders=("product", "count"),
    revenue=("revenue", "sum"),
    profit=("profit", "sum"),
)
summary["AOV"] = summary["revenue"] / summary["orders"]

# ---------- Sidebar filters ----------
st.sidebar.header("Filters")
channels = summary["channel"].unique()
regions = summary["region"].unique()
selected_channel = st.sidebar.multiselect("Select Channels", channels, default=channels)
selected_region = st.sidebar.multiselect("Select Regions", regions, default=regions)

filtered = summary[
    (summary["channel"].isin(selected_channel))
    & (summary["region"].isin(selected_region))
]

# ---------- KPIs ----------
st.title("Executive Dashboard")
col1, col2, col3 = st.columns(3)
col1.metric("Total Revenue", f"${filtered['revenue'].sum():,.0f}")
col2.metric("Total Orders", f"{filtered['orders'].sum():,}")
col3.metric("AOV", f"${filtered['AOV'].mean():.2f}")

# ---------- Bar chart ----------
fig = px.bar(
    filtered,
    x="channel",
    y="revenue",
    color="region",
    barmode="stack",
    color_discrete_sequence=px.colors.qualitative.Set2,
    title="Revenue by Channel and Region"
)
fig.update_layout(plot_bgcolor="white", paper_bgcolor="white")
st.plotly_chart(fig, use_container_width=True)

# ---------- Elasticity simulator ----------
st.header("Price Change Simulation")

def simulate_price_change(base_units, avg_price, elasticity, delta_p):
    demand_factor = (1 + delta_p) ** (-elasticity)
    proj_units = base_units * demand_factor
    proj_revenue = proj_units * avg_price * (1 + delta_p)
    return proj_units, proj_revenue

delta_p = st.slider("Price Change (%)", -0.2, 0.2, 0.05, step=0.01)
elasticity = st.slider("Elasticity (e)", 0.5, 2.0, 1.2, step=0.1)

base_units = filtered["orders"].sum()
avg_price = (filtered["revenue"].sum() / base_units) if base_units > 0 else 0

proj_units, proj_revenue = simulate_price_change(
    base_units=base_units,
    avg_price=avg_price,
    elasticity=elasticity,
    delta_p=delta_p,
)

st.write(f"Projected Units: {proj_units:,.0f}")
st.write(f"Projected Revenue: ${proj_revenue:,.0f}")

rev_change = proj_revenue - filtered["revenue"].sum()
st.metric("Revenue Δ", f"${rev_change:,.0f}")